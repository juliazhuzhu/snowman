

#ifndef __JSB_AUTO_H_
#define __JSB_AUTO_H_

#ifdef COCOS2D_JAVASCRIPT

#include "jsapi.h"
#include "jsfriendapi.h"
#include "ScriptingCore.h"
#include "JSBinding.h"

void register_jsb_soomla(JSContext *cx, JSObject *global);

#endif // COCOS2D_JAVASCRIPT

#endif //__JSB_AUTO_H_
