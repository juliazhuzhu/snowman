### v4.3.1 [view commit logs](https://github.com/soomla/cocos2dx-store/compare/v4.3.0...v4.3.1)

* Features
  * Added canAfford functionality
  * Fixing [issue #153](https://github.com/soomla/cocos2dx-store/issues/153) on GitHub

### v4.3.0 [view commit logs](https://github.com/soomla/cocos2dx-store/compare/v4.2.0...v4.3.0)

***Important***: there are some breaking changes. Read the changes carefully.

* New Features
* Work Without a Device! the code can work on other platforms (without in-app purchases testing)
* New local inventory that keeps all balances in memory so you don't need to go to the native DB. Saves JNI calls.
