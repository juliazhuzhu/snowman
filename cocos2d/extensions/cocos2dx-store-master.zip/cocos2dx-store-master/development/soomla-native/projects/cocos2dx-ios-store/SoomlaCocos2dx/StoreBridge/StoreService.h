
#import <Foundation/Foundation.h>

@interface StoreService : NSObject
+ (id)sharedStoreService;
@end
