
#import "CommonConsts.h"

@implementation CommonConsts {
}
const NSString *const JSON_JSON_TYPE = @"className";

const NSString *const JSON_JSON_TYPE_BADGE = @"BadgeReward";
const NSString *const JSON_JSON_TYPE_RANDOM = @"RandomReward";
const NSString *const JSON_JSON_TYPE_SEQUENCE = @"SequenceReward";
const NSString *const JSON_JSON_TYPE_SCHEDULE = @"Schedule";
const NSString *const JSON_JSON_TYPE_DATE_TIME_RANGE = @"DateTimeRange";
@end
