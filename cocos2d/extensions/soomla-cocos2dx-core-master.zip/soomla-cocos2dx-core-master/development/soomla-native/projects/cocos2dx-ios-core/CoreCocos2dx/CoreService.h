
#import <Foundation/Foundation.h>

@interface CoreService : NSObject
+ (id)sharedCoreService;
@end
