### v1.0.1 [view commit logs](https://github.com/soomla/soomla-cocos2dx-core/compare/v1.0.0...v1.0.1)

* Changes
  * Upgrading submodules

### v1.0.0

Initial version of the SOOMLA Core library for Cocos2d-x
